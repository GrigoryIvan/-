function filterBooks() {
    var input, filter, bookList, bookItems, title, i;
    input = document.getElementById('search');
    filter = input.value.toUpperCase();
    bookList = document.getElementById("book-list");
    bookItems = bookList.getElementsByClassName('book-item');
    
    for (i = 0; i < bookItems.length; i++) {
        title = bookItems[i].getElementsByTagName("h3")[0];
        if (title) {
            if (title.innerText.toUpperCase().indexOf(filter) > -1) {
                bookItems[i].style.display = "";
            } else {
                bookItems[i].style.display = "none";
            }
        }
    }
}