<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в систему</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="navbar-content">
                <div class="logo">Система</div>
                <div class="burger-menu">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="nav-menu">
                    <a href="#" class="nav-link">Главная</a>
                    <a href="#" class="nav-link">О системе</a>
                    <a href="#" class="nav-link">Контакты</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card mt-5">
            <h2 class="text-center">Вход в систему</h2>
            <?php
            session_start();
            $host = "localhost";
            $user = "root";
            $password = "";
            $db = "testdrive";
            $conn = new mysqli($host, $user, $password, $db);
            if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $login = $_POST["login"];
                $password = $_POST["password"];

                $stmt = $conn->prepare("SELECT * FROM users WHERE login=? AND password=?");
                $stmt->bind_param("ss", $login, $password);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows === 1) {
                    $_SESSION["login"] = $login;
                    echo '<div class="alert alert-success">Авторизация успешна!</div>';
                } else echo '<div class="alert alert-danger">Неверный логин или пароль.</div>';

                $stmt->close();
            }
            $conn->close();
            ?>
            <form method="POST" class="mt-4">
                <div class="form-group">
                    <label class="form-label">Логин:</label>
                    <input name="login" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Пароль:</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Войти</button>
            </form>
        </div>
    </div>

    <script>
        document.querySelector('.burger-menu').addEventListener('click', function() {
            document.querySelector('.nav-menu').classList.toggle('active');
        });
    </script>
</body>
</html>