<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: var(--spacing-md);
        }
        .admin-table th,
        .admin-table td {
            padding: var(--spacing-sm);
            border: 1px solid var(--border-color);
            text-align: left;
        }
        .admin-table th {
            background-color: var(--background-color);
            font-weight: 600;
        }
        .admin-table tr:nth-child(even) {
            background-color: var(--background-color);
        }
        .status-select {
            padding: var(--spacing-xs);
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius-sm);
            margin-right: var(--spacing-sm);
        }
    </style>
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
        header("Location: login.php");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "your_db_name");
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $stmt = $conn->prepare("UPDATE requests SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $_POST['status'], $_POST['request_id']);
        $stmt->execute();
        $stmt->close();
    }

    $result = $conn->query("SELECT * FROM requests");
    ?>
    <div class="container">
        <div class="card mt-5">
            <h2 class="text-center">Панель администратора</h2>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Пользователь</th>
                        <th>Авто</th>
                        <th>Дата</th>
                        <th>Статус</th>
                        <th>Действие</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['brand'] . ' ' . $row['model']; ?></td>
                        <td><?php echo $row['date'] . ' ' . $row['time']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
                                <select name="status" class="status-select">
                                    <option value="одобрено">Одобрено</option>
                                    <option value="выполнено">Выполнено</option>
                                    <option value="отклонено">Отклонено</option>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">Изменить</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>