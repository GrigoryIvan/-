<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отправка заявки</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "your_db_name");
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO requests (user_id, address, phone, date, time, license_series, license_number, license_issue_date, brand, model, payment, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ожидает')");
    $stmt->bind_param("issssssssss",
        $_SESSION['user_id'],
        $_POST['address'],
        $_POST['phone'],
        $_POST['date'],
        $_POST['time'],
        $_POST['license_series'],
        $_POST['license_number'],
        $_POST['license_issue_date'],
        $_POST['brand'],
        $_POST['model'],
        $_POST['payment']
    );

    $stmt->execute();
    $stmt->close();
    $conn->close();
    ?>
    <div class="container">
        <div class="card mt-5">
            <div class="alert alert-success">
                Заявка успешно отправлена!
            </div>
            <div class="text-center mt-4">
                <a href="create_request.php" class="btn btn-primary">Создать новую заявку</a>
            </div>
        </div>
    </div>
</body>
</html>