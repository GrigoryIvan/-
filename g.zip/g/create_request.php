<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание заявки</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="card mt-5">
            <h2 class="text-center">Создание заявки на тест-драйв</h2>
            <form action="submit_request.php" method="POST" class="mt-4">
                <div class="form-group">
                    <label class="form-label">Адрес:</label>
                    <input type="text" name="address" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Телефон:</label>
                    <input type="text" name="phone" class="form-control" placeholder="+7(XXX)-XXX-XX-XX" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Дата тест-драйва:</label>
                    <input type="date" name="date" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Время:</label>
                    <input type="time" name="time" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Серия ВУ:</label>
                    <input type="text" name="license_series" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Номер ВУ:</label>
                    <input type="text" name="license_number" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Дата выдачи ВУ:</label>
                    <input type="date" name="license_issue_date" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Марка:</label>
                    <select name="brand" class="form-control" required>
                        <option value="Toyota">Toyota</option>
                        <option value="BMW">BMW</option>
                        <option value="Lada">Lada</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Модель:</label>
                    <select name="model" class="form-control" required>
                        <option value="Camry">Camry</option>
                        <option value="Corolla">Corolla</option>
                        <option value="X5">X5</option>
                        <option value="Granta">Granta</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Тип оплаты:</label>
                    <div class="mt-2">
                        <input type="radio" name="payment" value="cash" required> Наличные
                        <input type="radio" name="payment" value="card" class="ml-3" required> Карта
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Отправить заявку</button>
            </form>
        </div>
    </div>
</body>
</html>