CREATE DATABASE IF NOT EXISTS test_drive CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE test_drive;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL
);

-- Таблица заявок
CREATE TABLE requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    license_series VARCHAR(10) NOT NULL,
    license_number VARCHAR(20) NOT NULL,
    license_issue_date DATE NOT NULL,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    payment ENUM('cash', 'card') NOT NULL,
    status ENUM('ожидает', 'одобрено', 'выполнено', 'отклонено') DEFAULT 'ожидает',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);