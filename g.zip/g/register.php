<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="navbar-content">
                <div class="logo">Система</div>
                <div class="burger-menu">
                    <i class="fas fa-bars"></i>
                </div>
                <div class="nav-menu">
                    <a href="login.php" class="nav-link">Вход</a>
                    <a href="register.php" class="nav-link active">Регистрация</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card mt-5">
            <h2 class="text-center">Регистрация</h2>
            <?php
            session_start();
            $host = "localhost";
            $user = "root";
            $password = "";
            $db = "testdrive";
            $conn = new mysqli($host, $user, $password, $db);
            if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $fio = trim($_POST["fio"]);
                $phone = trim($_POST["phone"]);
                $email = trim($_POST["email"]);
                $login = trim($_POST["login"]);
                $password = $_POST["password"];
                $password_confirm = $_POST["password_confirm"];
                $errors = [];

                // Валидация ФИО
                if (!preg_match("/^[А-Яа-яЁё\s]{2,50}$/u", $fio)) {
                    $errors[] = "ФИО должно содержать только русские буквы и пробелы (2-50 символов)";
                }

                // Валидация телефона
                if (!preg_match("/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/", $phone)) {
                    $errors[] = "Неверный формат телефона";
                }

                // Валидация email
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "Неверный формат email";
                }

                // Валидация логина
                if (strlen($login) < 3 || strlen($login) > 20) {
                    $errors[] = "Логин должен быть от 3 до 20 символов";
                }

                // Проверка существования логина
                $stmt = $conn->prepare("SELECT id FROM users WHERE login = ?");
                $stmt->bind_param("s", $login);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    $errors[] = "Этот логин уже занят";
                }
                $stmt->close();

                // Валидация пароля
                if (strlen($password) < 6) {
                    $errors[] = "Пароль должен быть не менее 6 символов";
                }
                if ($password !== $password_confirm) {
                    $errors[] = "Пароли не совпадают";
                }

                if (empty($errors)) {
                    // Хеширование пароля
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    
                    $stmt = $conn->prepare("INSERT INTO users (fio, phone, email, login, password) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssss", $fio, $phone, $email, $login, $hashed_password);
                    
                    if ($stmt->execute()) {
                        $_SESSION["success_message"] = "Регистрация прошла успешно! Теперь вы можете войти.";
                        header("Location: login.php");
                        exit();
                    } else {
                        echo '<div class="alert alert-danger">Ошибка при регистрации: ' . $stmt->error . '</div>';
                    }
                    $stmt->close();
                } else {
                    foreach ($errors as $error) {
                        echo '<div class="alert alert-danger">' . htmlspecialchars($error) . '</div>';
                    }
                }
            }
            $conn->close();
            ?>
            <form method="POST" class="mt-4" id="registerForm">
                <div class="form-group">
                    <label class="form-label">ФИО:</label>
                    <input name="fio" class="form-control" pattern="[А-Яа-яЁё\s]{2,50}" 
                           title="Введите ФИО на русском языке (2-50 символов)" required
                           value="<?php echo isset($_POST['fio']) ? htmlspecialchars($_POST['fio']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Телефон:</label>
                    <input name="phone" class="form-control" pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" 
                           placeholder="+7(XXX)-XXX-XX-XX" required
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Email:</label>
                    <input type="email" name="email" class="form-control" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Логин:</label>
                    <input name="login" class="form-control" minlength="3" maxlength="20" required
                           value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Пароль:</label>
                    <input type="password" name="password" class="form-control" minlength="6" required>
                    <small class="form-text">Минимум 6 символов</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Подтверждение пароля:</label>
                    <input type="password" name="password_confirm" class="form-control" minlength="6" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                    <a href="login.php" class="btn btn-secondary">Уже есть аккаунт? Войти</a>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Обработка телефона
        document.querySelector('input[name="phone"]').addEventListener('input', function(e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            e.target.value = !x[2] ? x[1] : '+7(' + x[1] + ')-' + x[2] + (x[3] ? '-' + x[3] : '') + (x[4] ? '-' + x[4] : '');
        });

        // Обработка бургер-меню
        document.querySelector('.burger-menu').addEventListener('click', function() {
            document.querySelector('.nav-menu').classList.toggle('active');
        });

        // Валидация формы
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.querySelector('input[name="password"]').value;
            const passwordConfirm = document.querySelector('input[name="password_confirm"]').value;
            
            if (password !== passwordConfirm) {
                e.preventDefault();
                alert('Пароли не совпадают');
            }
        });
    </script>
</body>
</html>